import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Plus, 
  LogOut, 
  User, 
  Calendar, 
  Clock,
  MoreVertical,
  Filter
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import ApiService from '../services/api';

const Dashboard = () => {
  const { user, logout, isGestor } = useAuth();
  const [quadros, setQuadros] = useState([]);
  const [quadroSelecionado, setQuadroSelecionado] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filtroSetor, setFiltroSetor] = useState('');

  useEffect(() => {
    carregarQuadros();
  }, []);

  const carregarQuadros = async () => {
    try {
      setLoading(true);
      const data = await ApiService.getQuadros();
      setQuadros(data);
      
      // Selecionar primeiro quadro automaticamente
      if (data.length > 0) {
        setQuadroSelecionado(data[0]);
      }
    } catch (error) {
      console.error('Erro ao carregar quadros:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'pendente': 'bg-gray-100 text-gray-800',
      'em_andamento': 'bg-blue-100 text-blue-800',
      'aprovado': 'bg-yellow-100 text-yellow-800',
      'concluido': 'bg-green-100 text-green-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status) => {
    const texts = {
      'pendente': 'Pendente',
      'em_andamento': 'Em Andamento',
      'aprovado': 'Aprovação',
      'concluido': 'Concluído'
    };
    return texts[status] || status;
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  const isOverdue = (dateString) => {
    if (!dateString) return false;
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  const setores = ['Social Media', 'Design', 'Tráfego Pago', 'Audiovisual', 'Comercial', 'Gestão'];

  const quadrosFiltrados = filtroSetor 
    ? quadros.filter(q => q.setor === filtroSetor)
    : quadros;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">
                Sistema Kanban
              </h1>
              <Badge variant="outline" className="text-sm">
                {user?.setor}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtrar
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setFiltroSetor('')}>
                    Todos os Setores
                  </DropdownMenuItem>
                  {setores.map(setor => (
                    <DropdownMenuItem 
                      key={setor}
                      onClick={() => setFiltroSetor(setor)}
                    >
                      {setor}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {user?.nome?.charAt(0)?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:block">{user?.nome}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <User className="h-4 w-4 mr-2" />
                    Perfil
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Sidebar com lista de quadros */}
      <div className="flex">
        <aside className="w-64 bg-white shadow-sm h-screen sticky top-0">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Quadros</h2>
              {isGestor && (
                <Button size="sm" variant="outline">
                  <Plus className="h-4 w-4" />
                </Button>
              )}
            </div>
            
            <div className="space-y-2">
              {quadrosFiltrados.map((quadro) => (
                <button
                  key={quadro.id}
                  onClick={() => setQuadroSelecionado(quadro)}
                  className={`w-full text-left p-3 rounded-lg transition-colors ${
                    quadroSelecionado?.id === quadro.id
                      ? 'bg-blue-50 border-blue-200 border'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium text-sm">{quadro.titulo}</div>
                  <div className="text-xs text-gray-500 mt-1">
                    {quadro.tipo === 'Setor' ? quadro.setor : quadro.cliente_nome}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Área principal do Kanban */}
        <main className="flex-1 p-6">
          {quadroSelecionado ? (
            <div>
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  {quadroSelecionado.titulo}
                </h2>
                <p className="text-gray-600">
                  {quadroSelecionado.tipo === 'Setor' 
                    ? `Setor: ${quadroSelecionado.setor}`
                    : `Cliente: ${quadroSelecionado.cliente_nome}`
                  }
                </p>
              </div>

              {/* Colunas do Kanban */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {quadroSelecionado.colunas?.map((coluna) => (
                  <div key={coluna.id} className="bg-gray-100 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">
                        {coluna.titulo}
                      </h3>
                      <Badge variant="secondary">
                        {coluna.cartoes?.length || 0}
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      {coluna.cartoes?.map((cartao) => (
                        <Card key={cartao.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between">
                              <CardTitle className="text-sm font-medium">
                                {cartao.titulo}
                              </CardTitle>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                                    <MoreVertical className="h-3 w-3" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem>Editar</DropdownMenuItem>
                                  <DropdownMenuItem>Mover</DropdownMenuItem>
                                  <DropdownMenuItem className="text-red-600">
                                    Excluir
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            {cartao.descricao && (
                              <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                                {cartao.descricao}
                              </p>
                            )}
                            
                            <div className="flex items-center justify-between text-xs">
                              <Badge 
                                className={getStatusColor(cartao.status)}
                                variant="secondary"
                              >
                                {getStatusText(cartao.status)}
                              </Badge>
                              
                              {cartao.prazo_entrega && (
                                <div className={`flex items-center space-x-1 ${
                                  isOverdue(cartao.prazo_entrega) 
                                    ? 'text-red-600' 
                                    : 'text-gray-500'
                                }`}>
                                  <Calendar className="h-3 w-3" />
                                  <span>{formatDate(cartao.prazo_entrega)}</span>
                                </div>
                              )}
                            </div>
                            
                            {cartao.responsavel_nome && (
                              <div className="flex items-center space-x-2 mt-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarFallback className="text-xs">
                                    {cartao.responsavel_nome.charAt(0).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-xs text-gray-600">
                                  {cartao.responsavel_nome}
                                </span>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                      
                      <Button 
                        variant="ghost" 
                        className="w-full border-2 border-dashed border-gray-300 h-12"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Cartão
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum quadro selecionado
              </h3>
              <p className="text-gray-600">
                Selecione um quadro na barra lateral para visualizar as tarefas
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;

